local orig = PlayerStandard._update_fwd_ray
function PlayerStandard:_update_fwd_ray(...)
	orig(self, ...)
	local unit = self._fwd_ray and self._fwd_ray.unit
	if unit and unit:base() and managers.enemy:is_enemy(unit) then
		if unit:character_damage() and unit:character_damage().dead and unit:character_damage():dead() then
			return
		end
	
		if unit:in_slot(8) and alive(unit:parent()) and unit:parent() then
			unit = unit:parent()
		end
		
		managers.game_play_central:auto_highlight_enemy(unit, true)
	end
end